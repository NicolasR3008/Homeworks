//Nicolas Rojas cabal -2226088

import React from 'react';

const titulo = "First App B)";


const FirstApp = () => {
  return (
    <div>
      <h1>{titulo} </h1>
      <span>10</span>
    </div>
  );
};

export default FirstApp;