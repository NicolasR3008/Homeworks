//Nicolas Rojas - 2226088
import React from 'react';

const Child = ({ categories }) => {
  return (
    <ul>
      {categories.map((cat, index) => (
        <li key={index}>{cat}</li>
      ))}
    </ul>
  );
};

export default Child;