//Nicolas Rojas - 2226088
import { useState } from 'react';
import Child from './Child';

const Parent = ({ categories, setCategories }) => {
  const [category, setCategory] = useState(''); 

  const handleInputChange = (event) => {
    setCategory(event.target.value);
  };

  const handleAddCategory = () => {
    if (category.trim() !== '') {
      setCategories([...categories, category]); 
      setCategory(''); 
    }
  };

  return (
    <div className="challenge-04">
      <input
        type="text"
        value={category}
        onChange={handleInputChange}
        placeholder="Escriba la categoria"
      />
      <button onClick={handleAddCategory}>Agregar categoria</button>

      <Child categories={categories} />
    </div>
  );
};

export default Parent;