//Nicolas Rojas - 2226088
import { useState } from 'react';
import Parent from './Parent';

const ComponentApp = () => {
  const [categories, setCategories] = useState([]); 

  return (
    <div>
      <h1>Challenge 04: Agregar categorias</h1>
      <Parent categories={categories} setCategories={setCategories} />
    </div>
  );
};

export default ComponentApp;