//Nicolas Rojas - 2226088
import { useState } from "react";

const FirstApp = ({ value }) => {
  const [counter, setCounter] = useState(value);

  const handleAdd = () => {
    setCounter(counter + 1);
  };

  const handleSubstract = () => {
    setCounter(counter - 1); 
  };

  const handleReset = () => {
    setCounter(value); 
  };

  const titulo = "contador";

  const containerStyles = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    flexDirection: "column",
    gap: "10px",
  };

  const buttonContainerStyles = {
    display: "flex",
    gap: "10px",
  };

  return (
    <div style={containerStyles}> 
      <h1>{titulo}</h1>
      <span>{counter}</span>
      <div style={buttonContainerStyles}>
        <button onClick={handleAdd}>+1</button>
        <button onClick={handleSubstract}>-1</button> 
        <button onClick={handleReset}>Reset</button> 
      </div>
    </div>
  );
};

export default FirstApp;