//Nicolas Rojas cabal-2226088


/*
*Regular Functions:
-this: Tiene su propio contexto "this", que depende de cómo se llama la función.
-Uso de arguments: Tiene acceso al objeto arguments, que contiene todos los argumentos pasados a la función.
Constructores:Puede ser usada como constructor (con new).
*/

//Funcion para ver si es par o impar:

function ParOImpar(numero) {
    if (numero % 2 === 0) {
      console.log(`${numero} es par.`);
    } else {
      console.log(`${numero} es impar.`);
    }
  }
  
  ParOImpar(4); 
  ParOImpar(7); 


  /* 
  *Arrow Function:
  - this: No tiene su propio this. Hereda el this del ámbito exterior (lexical scoping).
  -Uso de arguments: No tiene acceso al objeto arguments.
  -Constructores: No puede ser usada como constructor.
  -Return Implícito: Si el cuerpo de la función es una sola expresión, puedes omitir las llaves {} y el return.
  */

  //Funcion para ver si es par o impar:

  const esParOImparArrow = (numero) => {
    if (numero % 2 === 0) {
      console.log(`${numero} es par.`);
    } else {
      console.log(`${numero} es impar.`);
    }
  };
  
  // Ejemplo de uso
  esParOImparArrow(6); 
  esParOImparArrow(9);
