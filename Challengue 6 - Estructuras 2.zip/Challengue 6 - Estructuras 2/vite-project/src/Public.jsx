//Nicolas Rojas - 2226088
import React from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css';

const Public = () => {
  const navigate = useNavigate();

  return (
    <div className="container">
      <h1>Challenge 5</h1>
      <p>Página Pública</p>
      <hr />

      <div className="button-container">
        
        <button className="nav-button" onClick={() => navigate('/login')}>
          Iniciar Sesión
        </button>
      </div>
    </div>
  );
};

export default Public;